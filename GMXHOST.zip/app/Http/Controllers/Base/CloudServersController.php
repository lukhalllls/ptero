<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Traits\Controllers\JavascriptInjection;
use Illuminate\Support\Facades\DB;
use Pterodactyl\Services\Servers\ServerCreationService;
use Pterodactyl\Models\Nest;
use Pterodactyl\Models\Node;
use Pterodactyl\Contracts\Repository\ServerRepositoryInterface;
use Illuminate\Support\Str;

class CloudServersController extends Controller
{
    
    use JavascriptInjection;
    private $alert;
    protected $cache;

    public function __construct(ServerCreationService $creationService, AlertsMessageBag $alert, ServerRepositoryInterface $repository)
    {
        $this->repository = $repository;
        $this->creationService = $creationService;
        $this->alert = $alert;
    }

    public function choose(Request $request): View
    {
        $eggs = DB::table('cloudeggs')->get();

        return view('cloudservers.choose', [
            'eggs' => $eggs
        ]);
    }


    public function game(Request $request, $id): View
    {
        $id = (int) $id;
        $settings = DB::table('cloudsettings')->where('id', '=', (int) 1)->first();
        $users = DB::table('users')->where('id', '=', $request->user()->id)->get();
        $eggs = DB::table('cloudeggs')->where('id', '=', $id)->get();

        return view('cloudservers.game', [
            'settings' => $settings,
            'eggs' => $eggs,
            'id' => $id,
            'users' => $users
        ]);
    }

    public function creategame(Request $request, $id)
    {
        $users = DB::table('users')->where('id', '=', $request->user()->id)->get();
        $settings = DB::table('cloudsettings')->where('id', '=', (int) 1)->first();
        $eggs2 = DB::table('cloudeggs')->where('id', '=', $id)->first();
        $eggs = DB::table('eggs')->where('id', '=', $eggs2->id)->get();
        $name = $request->input('name');
        $desc = $request->input('desc');
        $ram = $request->input('ram');
        $disk = $request->input('disk');
        $allocation = $this->getAllocationId();

        $this->validate($request, [
            'name' => 'required',
            'ram' => 'required',
            'disk' => 'required',
        ]);

        foreach($users as $user) {
            if($ram < $settings->min_ram) {
                $this->alert->danger('You need te minimum of ' . $settings->min_ram . 'MB ram.')->flash();
                return redirect()->route('cloudservers.game', $id);
            }

            if($ram > $settings->max_ram) {
                $this->alert->danger('This is the more then the allowd valeu ' . $settings->max_ram . 'MB ram.')->flash();
                return redirect()->route('cloudservers.game', $id);
            }

            if($user->ram < $ram) {
                $this->alert->danger('You dont have so much ram.')->flash();
                return redirect()->route('cloudservers.game', $id);
            }

            if($disk < $settings->min_disk) {
                $this->alert->danger('You need te minimum of ' . $settings->min_disk . 'MB disk.')->flash();
                return redirect()->route('cloudservers.game', $id);
            }

            if($disk > $settings->max_disk) {
                $this->alert->danger('This is the more then the allowd valeu ' . $settings->max_disk . 'MB disk.')->flash();
                return redirect()->route('cloudservers.game', $id);
            }

            if($user->disk < $disk) {
                $this->alert->danger('You dont have so much disk.')->flash();
                return redirect()->route('cloudservers.game', $id);
            }

                if (!$allocation) return redirect()->back()->withErrors('We are sorry but at the moment there is no space left on our servers.');

                $eggs = DB::table('eggs')->where('id', '=', $eggs2->id)->get();
                foreach ($eggs as $egg) {
                    $nests = DB::table('nests')->where('id', '=', $egg->nest_id)->get();
                    foreach ($nests as $nest) {
                        if (!$nest || !$egg) return redirect()->back();
    
                        $data = [
                            'name' => $name,
                            'owner_id' => $request->user()->id,
                            'egg_id' => $eggs2->id,
                            'description' => $desc,
                            'allocation_id' => $allocation,
                            'environment' => [],
                            'memory' => $ram,
                            'disk' => $disk,
                            'cpu' => $settings->default_cpu,
                            'swap' => (int) 0,
                            'io' => $settings->default_io,
                            'cloudserver' => (int) 1,
                            'database_limit' => $settings->default_database,
                            'allocation_limit' => (int) $settings->default_allocation,
                            'image' => $eggs2->image,
                            'startup' => $eggs2->startup,
                            'start_on_completion' => true,
                        ];
    
                        foreach (DB::table('egg_variables')->get() as $var) {
                            $key = "v{$nest->id}-{$egg->id}-{$var->env_variable}";
                            $data['environment'][$var->env_variable] = $request->get($key, $var->default_value);
                        }
    
                        $server = $this->creationService->handle($data);
                        $server->save();
    
                        DB::table('cloudlogs')->insert([
                            'creator' => $request->user()->username,
                            'type' => $egg->name,
                            'name' => $name,
                            'ram' => $ram,
                            'disk' => $disk,
                        ]);
                        $totalram = DB::table('cloudsettings')->where('id', '=', (int) 1)->first();
    
                        DB::table('cloudsettings')->where('id', '=', 1)->update([
                            'totalram' => $totalram->totalram+$ram,
                            'totalservers' => $totalram->totalservers+1,
                        ]);

                        DB::table('users')->where('id', '=', $request->user()->id)->update([
                            'ram' => $user->ram-$ram,
                            'disk' => $user->disk-$disk,
                        ]);
                        
                $this->alert->success('You success fully created the server.')->flash();
                return redirect()->route('index');
            }
        }
    }
}

    private function getAllocationId($memory = 0, $attempt = 0)
    {
        
        if ($attempt > 6) return null;
        
        $node = Node::where('nodes.public', true)->where('nodes.maintenance_mode', false)->first();

        if (!$node) return false;

        $allocation = $node->allocations()->where('server_id', null)->inRandomOrder()->first();

        if (!$allocation) return getAllocationId($memory, $attempt+1);

        return $allocation->id;
    }
}